import java.net.*;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.io.*;

/**
 * Uses UDP sockets to behave like TCP
 * @author andreahu
 *
 */
public class rtp {
	// string key is client IP + client port
	private static HashMap<String, Connection> clientPortToConnection; // for demultiplexing
	private static int RECEIVE_PACKET_BUFFER_SIZE = 2000; // arbitrary value
//	private static int TIMEOUT = 2000; // arbitrary milliseconds
	private static final int MAX_SEGMENT_SIZE = 964; 
	
	private static DatagramSocket serverSocket;
	
	// For keeping track of which client we're accepting first
	private static Queue<String> orderOfClientAddresses = new LinkedList<String>();
	private static Queue<String> orderOfClientPorts = new LinkedList<String>();
	
	
	/*
	 * CLASS METHODS BELOW
	 */
	
	public static DatagramSocket listen(int port) throws SocketException {
		serverSocket = new DatagramSocket(port);
		return serverSocket;
	}
	
	public static void setServerSocket(DatagramSocket s) {
		serverSocket = s;
		System.out.println("static setter's server socket: " + serverSocket);
	}
	
	/**
	 * Makes a server socket for the application that the clients will connect to. <br>
	 * Only call this in the server upon startup.
	 * @param port
	 * @return
	 * @throws SocketException
	 */
	public static DatagramSocket makeServerSocket(int port) throws SocketException {
		System.out.println("rtp.makeServerSocket");
		serverSocket = new DatagramSocket(port);
		System.out.println("SERVER SOCKET: " + serverSocket.toString());
		return serverSocket;
	}
	
	/**
	 * Use this method to retrieve the server socket at the client.
	 * @return
	 */
	public static DatagramSocket getServerSocket() {
		return serverSocket;
	}
	
	/**
	 * Pop's the current client address off of the queue and returns it.
	 * @return
	 */
	public static String acceptClientAddress() {
		return orderOfClientAddresses.poll();
	}
	
	public static String acceptClientPort() {
		return orderOfClientPorts.poll();
	}
	
	/**
	 * Establishes an RTP connection using TCP's 3-way Handshake.
	 * Assigns window size to the connection.
	 * @param windowSizeInBytes
	 * @param clientSocket
	 * @param serverSocket
	 * @return whether or not the connection attempt succeeded
	 * @throws Exception 
	 */
	@SuppressWarnings("finally")
	public static boolean connect(int windowSizeInBytes, DatagramSocket clientSocket) throws Exception {
		
		if (clientSocket == null) {
			System.out.println("rtp.Connect: Client Socket is null");
			return false;
		}
		
		if (serverSocket == null) {
			System.out.println("rtp.Connect: Server Socket is null");
			return false;
		}
		
		String clientAddressStr = clientSocket.getInetAddress().getHostAddress();
		String clientPortStr = String.valueOf(clientSocket.getPort());
		
		int clientAddress = ByteBuffer.wrap(clientSocket.getInetAddress().getAddress()).getInt();
		int clientPort = clientSocket.getPort();
		
		if (getConnection(clientAddressStr, clientPortStr) != null) {
			System.out.println("Connection has already been established");
			return true;
		}
		
		try {
			Connection c = createConnection(clientSocket, serverSocket);
			c.setWindowSize(windowSizeInBytes);
			
			// NOTE: WE DO NOT NEED TO USE THE DATAGRAMSOCKET.CONNECT METHOD TO SEND PACKETS
			
			/*
			 * implementation of 3 way handshake
			 */
			
			// set states
			c.setClientState(ClientConnectionState.LISTEN);
			c.setServerState(ServerConnectionState.LISTEN);
			
			
			/*
			 * HANDSHAKE 1: CLIENT --> SERVER
			 */
			// Create SYNbit = 1, Seq = x packet
			Packet packet1 = new Packet(false, false, true, 0, 0, clientAddress, clientPort, null);
			byte[] packet1bytes = packet1.packetize();
			
			DatagramPacket p1 = new DatagramPacket(packet1bytes, packet1bytes.length, 
					serverSocket.getInetAddress(), serverSocket.getPort());
			
			// server receives packet
			DatagramPacket receivePacket = 
					new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			clientSocket.send(p1);
			c.setClientState(ClientConnectionState.SYN_SENT);
			serverSocket.receive(receivePacket); // is a blocking call
			
			// block until we get the first handshake
			// check syn bit here
			byte[] rtpPacket1 = receivePacket.getData();
			while (!getSynFromRtpPacket(rtpPacket1)) {
				serverSocket.receive(receivePacket);
				rtpPacket1 = receivePacket.getData();
			}
			c.setServerState(ServerConnectionState.SYN_RCVD);

			
			/*
			 * HANDSHAKE 2: SERVER --> CLIENT
			 */

			// Create SYNbit = 1, Seq = y, ACKbit = 1, ACKnum = x+1 packet
			Packet packet2 = new Packet(
					false, true, true, 7, packet1.getSequenceNumber() + 1, 
					clientAddress, clientPort, null);
			byte[] packet2bytes = packet2.packetize();
			DatagramPacket p2 = new DatagramPacket(packet2bytes, packet2bytes.length, 
					clientSocket.getInetAddress(), clientSocket.getPort());
			
			// client receives packet
			receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			serverSocket.send(p2);
			clientSocket.receive(receivePacket); // is a blocking call
			
			// block until we get the second handshake
			// check for SYN and ACK bits here
			byte[] rtpPacket2 = receivePacket.getData();
			while (!getSynFromRtpPacket(rtpPacket2) || !getAckFromRtpPacket(rtpPacket2)) {
				clientSocket.receive(receivePacket);
				rtpPacket2 = receivePacket.getData();
			}
			c.setClientState(ClientConnectionState.ESTAB);
			
			
			
			/*
			 * HANDSHAKE 3: CLIENT --> SERVER
			 */
			
			// Create ACKbit = 1, ACKnum = y+1 packet
			Packet packet3 = new Packet(false, true, false, 5, 
					packet2.getSequenceNumber() + 1, 
					clientAddress, clientPort, null);
			byte[] packet3bytes = packet3.packetize();
			DatagramPacket p3 = new DatagramPacket(packet3bytes, packet3bytes.length, 
					serverSocket.getInetAddress(), serverSocket.getPort());
			
			// server receives packet
			receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			clientSocket.send(p3);
			
			// block until we get the third handshake
			// check for ACK bit here
			serverSocket.receive(receivePacket); // is a blocking call
			byte[] rtpPacket3 = receivePacket.getData();
			while(!getAckFromRtpPacket(rtpPacket3)) {
				serverSocket.receive(receivePacket);
				rtpPacket3 = receivePacket.getData();
			}
			c.setServerState(ServerConnectionState.ESTAB);
			
			return true;
		} catch (Exception e) {
			System.out.println("<-----------rtp.Connect Failed-------------->");
			e.printStackTrace();
		} finally {
			// remove the failed connection if necessary
			String address = clientSocket.getInetAddress().getHostAddress();
			String port = String.valueOf(clientSocket.getPort());
			if (clientPortToConnection.containsKey(generateKey(address, port))) {
				clientPortToConnection.remove(address, port);
			}
			return false;
		}

	}
	
	/**
	 * Closes the RTP connection using the algorithm TCP uses. <br>
	 * Only closes the client socket. Leaves the server socket open. <br>
	 * Removes connection from rtp connection hashmap.
	 * @throws IOException 
	 */
	public static void close(String clientAddressStr, String clientPortStr) throws IOException {
		Connection c = getConnection(clientAddressStr, clientPortStr);
		DatagramSocket clientSocket = c.getClientSocket();
		
		InetAddress clientAddress = clientSocket.getInetAddress();
		int clientPort = clientSocket.getPort();
		
		if (c != null) {
			// make sure sockets are established
			if ((c.getClientState() != ClientConnectionState.ESTAB) || 
					(c.getServerState() != ServerConnectionState.ESTAB)) {
				System.out.println("rtp.close: cannot close-- not in the right states");
				return;
			}
			
			int clientAddressInt = ByteBuffer.wrap(clientSocket.getInetAddress().getAddress()).getInt();
			int clientPortInt = clientSocket.getPort();
			
			InetAddress serverAddress = c.getServerAddress();
			int serverPortInt = c.getServerPort();
			
			DatagramSocket serverSocket = c.getServerSocket();
			
			// implemented TCP close algorithm
			/*
			 * PART 1 of Closing
			 */
			// SEND PACKET 1: CLIENT --> SERVER
			// FIN = 1, seq = x
			Packet packet1 = new Packet(true, false, false, 1, 100, clientAddressInt, clientPortInt, null);
			byte[] packet1bytes = packet1.packetize();
			DatagramPacket dp1 = new DatagramPacket(packet1bytes, packet1bytes.length, serverAddress, serverPortInt);
			DatagramPacket receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			
			clientSocket.send(dp1);
			c.setClientState(ClientConnectionState.FIN_WAIT_1);
			
			serverSocket.receive(receivePacket);
			byte[] rtpPacket = receivePacket.getData();
			
			while (!getFinFromRtpPacket(rtpPacket)) {
				serverSocket.receive(receivePacket);
				rtpPacket = receivePacket.getData();
			}
			c.setServerState(ServerConnectionState.CLOSE_WAIT);
			
			// SEND ACK 1: SERVER --> CLIENT
			// ACK = 1, ACKnum = x+1
			Packet ack1 = new Packet(false, true, false, 50, getSeqNumFromRtpPacket(rtpPacket) + 1, clientAddressInt, clientPortInt, null);
			byte[] ack1bytes = ack1.packetize();
			DatagramPacket dp2 = new DatagramPacket(ack1bytes, ack1bytes.length, clientAddress, clientPort);
			receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			
			serverSocket.send(dp2);
			
			clientSocket.receive(receivePacket);
			rtpPacket = receivePacket.getData();
			while (!getAckFromRtpPacket(rtpPacket)) {
				clientSocket.receive(receivePacket);
				rtpPacket = receivePacket.getData();
			}
			c.setClientState(ClientConnectionState.FIN_WAIT_2);
			
			
			
			/*
			 * PART 2 of Closing
			 */
			// SEND PACKET 2: SERVER --> CLIENT
			// FIN = 1, seq = y
			Packet packet2 = new Packet(true, false, false, 0, 55, clientAddressInt, clientPortInt, null);
			byte[] packet2bytes = packet2.packetize();
			DatagramPacket dp3 = new DatagramPacket(packet2bytes, packet2bytes.length, clientAddress, clientPort);
			receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			
			serverSocket.send(dp3);
			c.setServerState(ServerConnectionState.LAST_ACK);
			
			clientSocket.receive(receivePacket);
			rtpPacket = receivePacket.getData();
			while (!getFinFromRtpPacket(rtpPacket)) {
				clientSocket.receive(receivePacket);
				rtpPacket = receivePacket.getData();
			}
			
			// WE ASSUME HERE THAT NO PACKETS ARE LOST, SO WE DON'T BOTHER WITH ACTUALLY WAITING 2x IN THE TIMED WAIT
			
			// SEND ACK 2: CLIENT --> SERVER
			// ACK = 1, ACKnum = y+1
			Packet packet3 = new Packet(false, true, false, 39, getSeqNumFromRtpPacket(rtpPacket) + 1, clientAddressInt, clientPort, null);
			byte[] packet3bytes = packet3.packetize();
			DatagramPacket dp4 = new DatagramPacket(packet3bytes, packet3bytes.length, serverAddress, serverPortInt);
			receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
			
			clientSocket.send(dp4);
			c.setClientState(ClientConnectionState.TIMED_WAIT);
			
			serverSocket.receive(receivePacket);
			rtpPacket = receivePacket.getData();
			while (!getAckFromRtpPacket(rtpPacket)) {
				serverSocket.receive(receivePacket);
				rtpPacket = receivePacket.getData();
			}
			c.setServerState(ServerConnectionState.CLOSED);
			
			c.setClientState(ClientConnectionState.CLOSED);
			
			// Closes client socket; Server Socket remains open
			c.getClientSocket().close();

			deleteConnection(clientAddressStr, clientPortStr);
		} else {
			System.out.println("cannot close nonexistent connection in rtp.close");
		}
	}
	
	/**
	 * Writes payload data from client buffer into byte buffer
	 * Clears the writeToBuffer before writing data to it.
	 * This should be called at the client every time an ACK is received.
	 * @param bytesRequested = size of a packet.
	 * @return number of bytes read (-1 if we're busy waiting, 0 if we're done)
	 */
	public static int readClientResult(byte[] writeToBuffer, String clientAddress, String clientPort) {
		Connection c = getConnection(clientAddress, clientPort);
		writeToBuffer = c.readClientResult();
		
		if (!c.getCanReadFromClientResultBuffer()) {
			return -1;
		}
		
		if (writeToBuffer != null) {
			return writeToBuffer.length;
		} else {
			return 0;
		}
	}
	
	/**
	 * Writes payload data from server buffer into byte buffer
	 * Clears the writeToBuffer before writing data to it.
	 * This should be called at the server every time an ACK is sent.
	 * @return received message size (-1 if we're busy waiting, 0 if we're done)
	 */
	public static int readServerResult(byte[] writeToBuffer, String clientAddress, String clientPort) {
		
		Connection c = getConnection(clientAddress, clientPort);
		writeToBuffer = c.readServerResult();
		
		if (!c.getCanReadFromServerResultBuffer()) {
			return -1;
		}
		if (writeToBuffer != null) {
			return writeToBuffer.length;
		} else {
			return 0;
		}
	}
	
	/**
	 * Given a data stream (byte buffer) at the client, it packetizes the data and sends it to the server. <p>
	 * At the same time, it needs to: <br>
	 *  - receive acknowledgements from the server <br>
	 *  - buffer packets at server <br>
	 *  - buffer packets at client <br>
	 *  - make sure the number of unacknowledged packets does not exceed the window size <br>
	 *  - make sure the number of packets at the server/client buffer does not exceed the max buffer size <br>
	 *  <p>
	 *  By the end of this, the server result and client results should be complete and ready for reading.
	 * @param toServer
	 * @param clientAddress
	 * @param clientPort
	 * @return
	 */
	public static void writeStreamFromClientToServer(byte[] data, String clientAddress, String clientPort) throws Exception {
		Connection c = getConnection(clientAddress, clientPort);
		if (c == null) {
			throw new Exception("rtp.writeStreamFromClientToServer: connection does not exist");
		}
		
		orderOfClientAddresses.add(clientAddress);
		orderOfClientPorts.add(clientPort);
		
		int windowSize = c.getWINDOW_SIZE();
		Queue<Packet> unacknowledgedPackets = new LinkedList<Packet>();
		/**
		 while packets_sent < window_size: (send initial packets to server all at once)
			 client.send packet
			 server.receive packet
			 if packet is not a dup
				 unacknowledgedSeqNums.add(packet.getseqnum)
		 while dataIndex < data.length: (start sending incrementally)
			 server sends next ack from the queue
			 move one packet-size of data from the serverQ to the serverResult
			 client.receive ack
			 if ack is not a dup:
				 update clientQ and clientResult
			 client sends next packet (dataindex to dataindex + packetsize)
			 dataindex += packetsize
		 **/

		// acknowledge packets and send more as necessary
		int startOfNextPayload = sendUpToTheWindowSizeToServer(data, c, windowSize, unacknowledgedPackets);
		int lastIndexInData = data.length - 1;
		int dataRemaining = lastIndexInData - startOfNextPayload;
		
		if (dataRemaining <= 0) { // entire data array has already been sent
			acknowledgeAllUnackedPacketsAtClient(unacknowledgedPackets, c);
			unloadRemainingBuffersToResultQueues(c);
			return;
		}
		
		// while there is data to send, send one packet and acknowledge it incrementally
		while (startOfNextPayload < lastIndexInData) {
			sendAck(unacknowledgedPackets.poll(), c);
			receiveAckAtClient(c);
			sendPacketToServerAndReceiveAtServer(startOfNextPayload, dataRemaining, data, c, unacknowledgedPackets);
			
			startOfNextPayload = startOfNextPayload + MAX_SEGMENT_SIZE;
		}
		
		// at this point, all data should have been sent
		// acknowledge the remaining unacknowledged packets
		// unload the remaining buffers
		acknowledgeAllUnackedPacketsAtClient(unacknowledgedPackets, c);
		unloadRemainingBuffersToResultQueues(c);
		
		// TODO: SET CONNECTION AS READY TO READ FROM RESULT BUFFER
		c.setCanReadFromServerResultBuffer(true);
	}
	
	/**
	 * Sends byte[] data to the server and acknowledges it.
	 * Sets the flag in the connection so that we can read from client buffer when we're done.
	 * @param data
	 * @param clientAddress
	 * @param clientPort
	 * @throws Exception
	 */
	public static void writeStreamFromServerToClient(byte[] data, String clientAddress, String clientPort) throws Exception {
		Connection c = getConnection(clientAddress, clientPort);
		if (c == null) {
			throw new Exception("rtp.writeStreamFromServerToClient: connection does not exist");
		}
		
		int windowSize = c.getWINDOW_SIZE();
		Queue<Packet> unacknowledgedPackets = new LinkedList<Packet>();
		
		
		// acknowledge packets and send more as necessary
		int startOfNextPayload = sendUpToTheWindowSizeToClient(data, c, windowSize, unacknowledgedPackets);
		int lastIndexInData = data.length - 1;
		int dataRemaining = lastIndexInData - startOfNextPayload;
		
		
		
		if (dataRemaining <= 0) { // entire data array has already been sent
			acknowledgeAllUnackedPacketsAtClient(unacknowledgedPackets, c);
			unloadRemainingBuffersToResultQueues(c);
			return;
		}
		
		// while there is data to send, send one packet and acknowledge it incrementally
		while (startOfNextPayload < lastIndexInData) {
			sendAckToServer(unacknowledgedPackets.poll(), c);
			receiveAckAtServer(c);
			sendPacketToClientAndReceiveAtClient(startOfNextPayload, dataRemaining, data, c, unacknowledgedPackets);
			
			startOfNextPayload = startOfNextPayload + MAX_SEGMENT_SIZE;
		}
		
		// at this point, all data should have been sent
		// acknowledge the remaining unacknowledged packets
		// unload the remaining buffers
		acknowledgeAllUnackedPacketsAtClient(unacknowledgedPackets, c);
		unloadRemainingBuffersToResultQueues(c);
		
		c.setCanReadFromClientResultBuffer(true);
	}
	
	/**
	 * Moves all the bytes in the client and server buffers into the result queues
	 * inside the connection object.
	 * @param c
	 */
	private static void unloadRemainingBuffersToResultQueues(Connection c) {
		c.moveBytesFromBufferToClientResult(c.getCurrentClientBufferSize());
		c.moveBytesFromBufferToServerResult(c.getCurrentServerBufferSize());
	}
	
	/**
	 * Server sends and Client receives an ack for all the unacknowledged packets remaining. <p>
	 * @param unacknowledgedPackets
	 * @param c
	 * @throws IOException
	 */
	private static void acknowledgeAllUnackedPacketsAtClient(Queue<Packet> unacknowledgedPackets, Connection c) throws IOException {
		// send acknowledgements (Server --> Client) for all the packets
		for (Packet p : unacknowledgedPackets) {
			sendAckToServer(p, c);
			receiveAckAtServer(c);
			// no data to send from client-->server so we skip that part			
		}
	}
	
	/**
	 * Receives an acknowledgement at the server. <p>
	 * Moves 1 packet's worth of data from buffer to result at client and server.
	 * 
	 * @param c
	 * @throws IOException
	 */
	private static void receiveAckAtServer(Connection c) throws IOException {
		// TODO Auto-generated method stub
		// receive the ack at server
		DatagramPacket receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
		c.getServerSocket().receive(receivePacket);
		byte[] receiveBytes = receivePacket.getData();
		// move ack payload to the Server buffer
		c.addToServerBuffer(getAckNumFromRtpPacket(receiveBytes), getPayloadFromRtpPacket(receiveBytes));
		int serverBytesToMove = Math.min(c.getCurrentClientBufferSize(), Packet.getMaxSegmentSize());
		// move 1 packet's worth of data or less to the Server result
		c.moveBytesFromBufferToServerResult(serverBytesToMove);
		
		// move 1 packet's worth of data or less to the Client result
		int clientBytesToMove = Math.min(c.getCurrentClientBufferSize(), Packet.getMaxSegmentSize());
		c.moveBytesFromBufferToServerResult(clientBytesToMove);
	}

	/**
	 * Sends an ack to the Server using data from the packet passed in.
	 * @param p
	 * @param c
	 * @throws IOException
	 */
	
	private static void sendAckToServer(Packet p, Connection c) throws IOException {
		// TODO Auto-generated method stub
		int clientAddressInt = ByteBuffer.wrap(c.getClientAddress().getAddress()).getInt();
		int clientPortInt = c.getClientPort();
		
		int newAckNum = p.getSequenceNumber() + 1;
		int newSeqNum = p.getAckNumber();
		Packet ack = new Packet(false, true, false, newSeqNum, newAckNum, clientAddressInt, clientPortInt, null);
		ack.setRemainingBufferSize(c.getRemainingServerBufferSize());
		byte[] ackBytes = ack.packetize();
		DatagramPacket dpAck = new DatagramPacket(ackBytes, ackBytes.length, c.getServerAddress(), c.getServerPort());
		c.getClientSocket().send(dpAck);
	}

	/**
	 * Receives an acknowledgement at the client. <p>
	 * Moves 1 packet's worth of data from buffer to result at client and server.
	 * 
	 * @param c
	 * @throws IOException
	 */
	private static void receiveAckAtClient(Connection c) throws IOException {
		// receive the ack
		DatagramPacket receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
		c.getClientSocket().receive(receivePacket);
		byte[] receiveBytes = receivePacket.getData();
		// move ack payload to the client buffer
		c.addToClientBuffer(getAckNumFromRtpPacket(receiveBytes), getPayloadFromRtpPacket(receiveBytes));
		int clientBytesToMove = Math.min(c.getCurrentClientBufferSize(), Packet.getMaxSegmentSize());
		// move 1 packet's worth of data or less to the client result
		c.moveBytesFromBufferToClientResult(clientBytesToMove);
		
		// move 1 packet's worth of data or less to the server result
		int serverBytesToMove = Math.min(c.getCurrentServerBufferSize(), Packet.getMaxSegmentSize());
		c.moveBytesFromBufferToServerResult(serverBytesToMove);
	}
	

	/**
	 * Sends an ack to the client using data from the packet passed in.
	 * @param p
	 * @param c
	 * @throws IOException
	 */
	private static void sendAck(Packet p, Connection c) throws IOException {
		int clientAddressInt = ByteBuffer.wrap(c.getClientAddress().getAddress()).getInt();
		int clientPortInt = c.getClientPort();
		
		int newAckNum = p.getSequenceNumber() + 1;
		int newSeqNum = p.getAckNumber();
		Packet ack = new Packet(false, true, false, newSeqNum, newAckNum, clientAddressInt, clientPortInt, null);
		ack.setRemainingBufferSize(c.getRemainingServerBufferSize());
		byte[] ackBytes = ack.packetize();
		DatagramPacket dpAck = new DatagramPacket(ackBytes, ackBytes.length, c.getClientAddress(), c.getClientPort());
		c.getServerSocket().send(dpAck);
	}
	
	
	/**
	 * Sends up to the window size # of packets to Server but does not acknowledge them
	 * @param data
	 * @param c
	 * @param windowSize
	 * @param unacknowledgedPackets
	 * @return the number of bytes that haven't been sent by the client
	 * @throws IOException 
	 */
	private static int sendUpToTheWindowSizeToServer(byte[] data, Connection c, int windowSize, Queue<Packet> unacknowledgedPackets) throws IOException {
		int dataRemaining = 0;
		int startOfNextPayload = 0;
		int lastIndexOfData = data.length - 1;
		for (int packetsSent = 0; packetsSent < windowSize; packetsSent++) {
			startOfNextPayload = packetsSent * MAX_SEGMENT_SIZE;
			dataRemaining = lastIndexOfData - startOfNextPayload; // in bytes
			
			sendPacketToServerAndReceiveAtServer(startOfNextPayload, dataRemaining, data, c, unacknowledgedPackets);
		}
		return startOfNextPayload;
	}
	
	/**
	 * Sends up to the window size # of packets to Client but does not acknowledge them
	 * @param data
	 * @param c
	 * @param windowSize
	 * @param unacknowledgedPackets
	 * @return the number of bytes that haven't been sent by the server
	 * @throws IOException 
	 */
	private static int sendUpToTheWindowSizeToClient(byte[] data, Connection c, int windowSize, Queue<Packet> unacknowledgedPackets) throws IOException {
		int dataRemaining = 0;
		int startOfNextPayload = 0;
		int lastIndexOfData = data.length - 1;
		for (int packetsSent = 0; packetsSent < windowSize; packetsSent++) {
			startOfNextPayload = packetsSent * MAX_SEGMENT_SIZE;
			dataRemaining = lastIndexOfData - startOfNextPayload; // in bytes
			
			sendPacketToClientAndReceiveAtClient(startOfNextPayload, dataRemaining, data, c, unacknowledgedPackets);
		}
		return startOfNextPayload;
	}
	
	/**
	 * Sends a packet from the byte[] data to Client
	 * @param startOfNextPayload
	 * @param dataRemaining
	 * @param data
	 * @param c
	 * @param unacknowledgedPackets
	 * @throws IOException 
	 */
	private static void sendPacketToClientAndReceiveAtClient(
			int startOfNextPayload, int dataRemaining, byte[] data,
			Connection c, Queue<Packet> unacknowledgedPackets) throws IOException {
		// TODO Auto-generated method stub
		int clientAddressInt = ByteBuffer.wrap(c.getClientAddress().getAddress()).getInt();
		byte[] payload;
		
		if (dataRemaining > MAX_SEGMENT_SIZE) {
			// haven't reached the end
			payload = new byte[MAX_SEGMENT_SIZE];
			// copy over the payload
			for (int i = 0; i < MAX_SEGMENT_SIZE; i++) {
				payload[i] = data[i + startOfNextPayload];
			}
		} else if ((dataRemaining < MAX_SEGMENT_SIZE) && (dataRemaining > 0)){
			// the last packet is within the max window size
			payload = new byte[dataRemaining];
			// copy over the last packet
			for (int i = 0; i < dataRemaining; i++) {
				payload[i] = data[i + startOfNextPayload];
			}
		} else { 
			// we've sent all the packets before the max window size
			return;
		}
		// send packet to Client
		Packet rtpToClient = new Packet(false, false, false, startOfNextPayload, 0, clientAddressInt, c.getClientPort(), payload);
		rtpToClient.setRemainingBufferSize(c.getRemainingClientBufferSize());
		DatagramPacket packetToClient = new DatagramPacket(payload, payload.length, c.getClientAddress(), c.getClientPort());
		c.getServerSocket().send(packetToClient);
		// receive packet at Client
		DatagramPacket receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
		c.getServerSocket().receive(receivePacket);
		// convert to rtp packet
		byte[] rtpResultBytes = receivePacket.getData(); 
		Packet rtpResultPacket = rtpBytesToPacket(rtpResultBytes);
		
		// makes sure it isn't a duplicate before adding to the server buffer; does not acknowledge; adds to hashset
		c.addToClientBuffer(rtpResultPacket.getAckNumber(), rtpResultPacket.getPayload());
		unacknowledgedPackets.add(rtpResultPacket);
		
	}

	/**
	 * Sends a packet from the byte[] data to server
	 * @param startOfNextPayload
	 * @param dataRemaining
	 * @param data
	 * @param c
	 * @param unacknowledgedPackets
	 * @throws IOException
	 */
	private static void sendPacketToServerAndReceiveAtServer(int startOfNextPayload, int dataRemaining, byte[] data, Connection c,
			Queue<Packet> unacknowledgedPackets) throws IOException {
		int clientAddressInt = ByteBuffer.wrap(c.getClientAddress().getAddress()).getInt();
		byte[] payload;
		
		if (dataRemaining > MAX_SEGMENT_SIZE) {
			// haven't reached the end
			payload = new byte[MAX_SEGMENT_SIZE];
			// copy over the payload
			for (int i = 0; i < MAX_SEGMENT_SIZE; i++) {
				payload[i] = data[i + startOfNextPayload];
			}
		} else if ((dataRemaining < MAX_SEGMENT_SIZE) && (dataRemaining > 0)){
			// the last packet is within the max window size
			payload = new byte[dataRemaining];
			// copy over the last packet
			for (int i = 0; i < dataRemaining; i++) {
				payload[i] = data[i + startOfNextPayload];
			}
		} else { 
			// we've sent all the packets before the max window size
			return;
		}
		// send packet
		Packet rtpToServer = new Packet(false, false, false, startOfNextPayload, 0, clientAddressInt, c.getClientPort(), payload);
		rtpToServer.setRemainingBufferSize(c.getRemainingClientBufferSize());
		DatagramPacket packetToServer = new DatagramPacket(payload, payload.length, c.getServerAddress(), c.getServerPort());
		c.getClientSocket().send(packetToServer);
		// receive packet
		DatagramPacket receivePacket = new DatagramPacket(new byte[RECEIVE_PACKET_BUFFER_SIZE], RECEIVE_PACKET_BUFFER_SIZE);
		c.getServerSocket().receive(receivePacket);
		// convert to rtp packet
		byte[] rtpResultBytes = receivePacket.getData(); 
		Packet rtpResultPacket = rtpBytesToPacket(rtpResultBytes);
		
		// makes sure it isn't a duplicate before adding to the server buffer; does not acknowledge; adds to hashset
		c.addToServerBuffer(rtpResultPacket.getAckNumber(), rtpResultPacket.getPayload());
		unacknowledgedPackets.add(rtpResultPacket);
	}
	
	/**
	 * Converts an array of rtpResultBytes into an rtp packet object
	 * @param rtpResultBytes
	 * @return
	 */
	private static Packet rtpBytesToPacket(byte[] rtpResultBytes) {
		boolean FIN = getFinFromRtpPacket(rtpResultBytes);
		boolean ACK = getAckFromRtpPacket(rtpResultBytes);
		boolean SYN = getSynFromRtpPacket(rtpResultBytes);
		int seqNum = getSeqNumFromRtpPacket(rtpResultBytes);
		int ackNum = getAckNumFromRtpPacket(rtpResultBytes);
		int remainingBufferSize = getRemainingBufferSizeFromRtpPacket(rtpResultBytes);
		int clientAddress = getClientAddressFromRtpPacket(rtpResultBytes);
		int clientPort = getClientPortFromRtpPacket(rtpResultBytes);
		byte[] payload = getPayloadFromRtpPacket(rtpResultBytes);
		
		Packet result = new Packet(FIN, ACK, SYN, seqNum, ackNum, clientAddress, clientPort, payload);
		result.setRemainingBufferSize(remainingBufferSize);
		
		return result;
	}


	
	/*
	 * PRIVATE METHODS
	 */
	
	private static boolean getFinFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(0);
		if (resultAsInt == 1) {
			return true;
		}
		return false;
	}
	
	private static boolean getAckFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(1);
		if (resultAsInt == 1) {
			return true;
		}
		return false;
	}
	
	private static boolean getSynFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(2);
		if (resultAsInt == 1) {
			return true;
		}
		return false;
	}
	
	private static int getSeqNumFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(3);
		return resultAsInt;
	}
	
	private static int getAckNumFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(4);
		return resultAsInt;
	}
	
	private static int getRemainingBufferSizeFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(5);
		return resultAsInt;
	}
	
	private static int getPayloadSizeFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(6);
		return resultAsInt;
	}
	
	private static int getClientAddressFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(7);
		return resultAsInt;
	}
	
	private static int getClientPortFromRtpPacket(byte[] rtpPacket) {
		ByteBuffer b = ByteBuffer.wrap(rtpPacket);
		int resultAsInt = b.getInt(8);
		return resultAsInt;
	}
	
	private static byte[] getPayloadFromRtpPacket(byte[] rtpPacket) {
		int payloadSize = getPayloadSizeFromRtpPacket(rtpPacket);
		int payloadStartIndex = 36; // first 36 (indices 0-35) bytes are header values
		byte[] result = new byte[payloadSize];
		
		// copy the payload over
		for (int i = 0; i < payloadSize; i++) {
			result[i] = rtpPacket[payloadStartIndex + i];
		}
		
		return result;
	}
	
	/**
	 * Generates a key for the hash map based on the clientAddress and clientPort
	 * @param clientAddress
	 * @param clientPort
	 * @return unique client key for mapping
	 */
	private static String generateKey(String clientAddress, String clientPort) {
		if (clientAddress == null || clientAddress.equals("") ) {
			System.out.println("no clientAddress in rtp.generateKey");
			return null;
		} else if (clientPort == null || clientPort.equals("")) {
			System.out.println("no clientPort in rtp.generateKey");
			return null;
		}
		return new String(clientAddress + clientPort);
	}
	
	/**
	 * Retrieves a connection from the hash map.
	 * @param clientAddress
	 * @param clientPort
	 * @return Connection or null if it has not been created
	 */
	private static Connection getConnection(String clientAddress, String clientPort) {
		String key = generateKey(clientAddress, clientPort);
		if (clientPortToConnection.containsKey(key)) {
			return clientPortToConnection.get(key);
		} else {
			System.out.println("cannot retrieve connection via rtp.getConnection");
			return null;
		}
	}
	
	/**
	 * Returns true if the connection was deleted. 
	 * Returns false if there was no connection to delete.
	 * @param clientAddress
	 * @param clientPort
	 * @return whether or not the desired connection was available to delete
	 */
	private static boolean deleteConnection(String clientAddress, String clientPort) {
		String key = generateKey(clientAddress, clientPort);
		return clientPortToConnection.remove(key) != null;
		
	}
	
	/**
	 * Creates a connection object and adds it to the hashmap.
	 * Does not actually establish a TCP connection. This is just for
	 * rtp representation for easy access later on.
	 * @param clientSocket
	 * @param serverSocket
	 * @return Connection representing the two sockets in hashmap
	 * @throws Exception for unconnected or null sockets
	 */
	private static Connection createConnection(DatagramSocket clientSocket, DatagramSocket serverSocket) throws Exception {
		if (clientSocket == null) {
			throw new Exception("clientSocket is null in createConnection()");
		} else if (clientSocket.getPort() == -1) {
			throw new Exception("clientSocket is not connected in createConnection()");
		} else if (serverSocket == null) {
			throw new Exception("serverSocket is null in createConnection()");
		} else if (serverSocket.getPort() == -1) {
			throw new Exception("serverSocket is not connected in createConnection()");
		}
		
		Connection c = new Connection(clientSocket, serverSocket);
		String key = generateKey(
				clientSocket.getInetAddress().getHostAddress(), 
				String.valueOf(clientSocket.getPort()));
		clientPortToConnection.put(key, c);
		return c;	
	}
	
}
