
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Connections represent RTP connections for easy variable access
 * within the RTP class.
 * @author andreahu
 *
 */
public class Connection {
//	private static final int BUFFER_SIZE = 500;
	private Queue<Byte> clientBuffer;
	private Queue<Byte> serverBuffer;
	private static final int MAX_RTP_PACKET_SIZE = 1000;
	private int WINDOW_SIZE;
	private ClientConnectionState clientState;
	private ServerConnectionState serverState;
	private HashSet<Integer> receivedSequenceNumbers; // for checking for duplicates via seq num
	private HashSet<Integer> receivedAckNumbers; // for checking for duplicates via ack num
	private InetAddress serverAddress;
	private int serverPort;
	private InetAddress clientAddress; 
	private int clientPort;
	private DatagramSocket clientSocket; // for closing a connection
	private DatagramSocket serverSocket; // for closing a connection
	private Queue<Byte> clientResult;
	private Queue<Byte> serverResult;
	
	private boolean canReadFromClientResultBuffer = false;
	private boolean canReadFromServerResultBuffer = false;
	
	
	/*
	 * CONSTRUCTOR
	 */
	
	/**
	 * Creates a new Connection object. Does not instantiate the window size
	 */
	public Connection(DatagramSocket clientSocket, DatagramSocket serverSocket) {
		clientBuffer = new LinkedList<Byte>();
		serverBuffer = new LinkedList<Byte>(); 
		
		clientState = ClientConnectionState.CLOSED;
		serverState = ServerConnectionState.CLOSED;
		
		receivedSequenceNumbers = new HashSet<Integer>();
		receivedAckNumbers = new HashSet<Integer>();
		
		serverAddress = serverSocket.getInetAddress();
		clientAddress = clientSocket.getInetAddress();
		serverPort = serverSocket.getPort();
		clientPort = clientSocket.getPort();
		this.clientSocket = clientSocket;
		this.serverSocket = serverSocket;
		
		clientResult = new LinkedList<Byte>();
		serverResult = new LinkedList<Byte>();
		
	}
	
	/*
	 * METHODS BELOW
	 */
	
	public void setCanReadFromClientResultBuffer(boolean value) {
		this.canReadFromClientResultBuffer = value;
	}
	
	public void setCanReadFromServerResultBuffer(boolean value) {
		this.canReadFromServerResultBuffer = value;
	}
	
	public boolean getCanReadFromClientResultBuffer() {
		return this.canReadFromClientResultBuffer;
	}
	
	public boolean getCanReadFromServerResultBuffer() {
		return this.canReadFromServerResultBuffer;
	}
	
	private void moveBytesFromBufferToResult(int numBytes, Queue<Byte> from, Queue<Byte> to) {
		for (int i = 0; i < numBytes; i++) {
			to.add(from.poll());
		}
	}
	
	public void moveBytesFromBufferToClientResult(int numBytes) {
		moveBytesFromBufferToResult(numBytes, clientBuffer, clientResult);
	}
	
	public void moveBytesFromBufferToServerResult(int numBytes) {
		moveBytesFromBufferToResult(numBytes, serverBuffer, serverResult);
	}
	
	public Queue<Byte> getClientResult() {
		return clientResult;
	}
	
	public Queue<Byte> getServerResult() {
		return serverResult;
	}
	
	public DatagramSocket getClientSocket() {
		return clientSocket;
	}
	
	public DatagramSocket getServerSocket() {
		return serverSocket;
	}
	
	public int getServerPort() {
		return serverPort;
	}
	
	public int getClientPort() {
		return clientPort;
	}
	
	public int getWINDOW_SIZE() {
		return WINDOW_SIZE;
	}

	public void setWINDOW_SIZE(int size) {
		WINDOW_SIZE = size;
	}

	/**
	 * 
	 * @return client state for this connection
	 */
	public ClientConnectionState getClientState() {
		return clientState;
	}
	
	/**
	 * 
	 * @return server state for this connection
	 */
	public ServerConnectionState getServerState() {
		return serverState;
	}
	
	/**
	 * Sets the client state to c
	 * @param c
	 */
	public void setClientState(ClientConnectionState c) {
		clientState = c;
	}
	
	/**
	 * Sets the server state to s
	 * @param s
	 */
	public void setServerState(ServerConnectionState s) {
		serverState = s;
	}
	
	
	/**
	 * Only adds non-duplicate ack payloads to the client buffer.
	 * Does not acknowledge the packet.
	 * Adds sequence number to hash map.
	 * @param ackNum
	 * @param payload
	 */
	public void addToClientBuffer(int ackNum, byte[] payload) {
		if (!isDuplicateAckNum(ackNum)) {
			receivedAckNumbers.add(ackNum);
			int payloadSize = payload.length;
			for (int i = 0; i < payloadSize; i++) {
				clientBuffer.add(payload[i]);
			}
		}
	}
	
	/**
	 * Only adds non-duplicate sequence number payloads to the server buffer. 
	 * Does not acknowledge the packet.
	 * Adds to the sequence number to hash map.
	 * @param ackNum
	 * @param payload
	 */
	public void addToServerBuffer(int seqNum, byte[] payload) {
		if (!isDuplicateSeqNum(seqNum)) {
			receivedSequenceNumbers.add(seqNum);
			int payloadSize = payload.length;
			for (int i = 0; i < payloadSize; i++) {
				serverBuffer.add(payload[i]);
			}
		}
	}

	/**
	 * 
	 * @param sequenceNumber
	 * @return whether we've already received this sequence number
	 */
	private boolean isDuplicateSeqNum(int sequenceNumber) {
		return receivedSequenceNumbers.contains(sequenceNumber);
	}
	
	/**
	 * 
	 * @param ackNum
	 * @return whether we've already received this acknoweldgement
	 */
	private boolean isDuplicateAckNum(int ackNum) {
		return receivedAckNumbers.contains(ackNum);
	}
	
	
	/**
	 * Sets the window size. Do this during rtp.connect().
	 * @param size
	 */
	public void setWindowSize(int size) {
		this.setWINDOW_SIZE(size);
	}
	
	/**
	 * Use to get the value for an ACK header
	 * @return number of bytes remaining in client buffer
	 */
	public int getRemainingClientBufferSize() {
		return WINDOW_SIZE * MAX_RTP_PACKET_SIZE - clientBuffer.size();
	}
	
	/**
	 * Use to get the value for an ACK header
	 * @return number of bytes remaining in server buffer
	 */
	public int getRemainingServerBufferSize() {
		return WINDOW_SIZE * MAX_RTP_PACKET_SIZE - serverBuffer.size();
	}
	
	/**
	 * For demultiplexing
	 * @return server address containing IP # and Host #
	 */
	public InetAddress getServerAddress() {
		return serverAddress;
	}
	
	/**
	 * For demultiplexing
	 * @return client address containing IP # and Host #
	 */
	public InetAddress getClientAddress() {
		return clientAddress;
	}
	
	public int getCurrentClientBufferSize() {
		return clientBuffer.size();
	}
	
	public int getCurrentServerBufferSize() {
		return serverBuffer.size();
	}
	
	
	/**
	 * Returns the min(numBytes, length of the queue) bytes of the 
	 * client result in a byte array. 
	 * 
	 * This is done on a new array each time so there should not be any legacy data.
	 * @param numBytes
	 * @return byte array of the entire result from client, or null if no result
	 */
//	public byte[] readClientResult(int numBytes) {
//		return readResult(numBytes, clientResult);
//	}
	
	public byte[] readClientResult() {
		return readResult(clientResult);
	}
	
	/**
	 * Returns the min(numBytes, length of the queue) bytes of the 
	 * server result in a byte array. 
	 * 
	 * This is done on a new array each time so there should not be any legacy data.
	 * @param numBytes
	 * @return byte array of the entire result from server, or null if no result
	 */
//	public byte[] readServerResult(int numBytes) {
//		return readResult(numBytes, serverResult);
//	}
	public byte[] readServerResult() {
		return readResult(serverResult);
	}
	
	/**
	 * Takes a byte queue and pops the appropriate number of bytes
	 * into a byte array and returns it. This is done on a new array 
	 * each time so there should not be any legacy data.
	 * @param numBytes
	 * @param buffer
	 * @return byte array of the entire result, or null if there is no result
	 */
	private byte[] readResult(Queue<Byte> buffer) {
		int numBytesToRead = buffer.size();
		
		if (numBytesToRead == 0) {
			return null;
		} else {
			byte[] result = new byte[numBytesToRead];
			
			for (int i = 0; i < numBytesToRead; i++) {
				result[i] = buffer.poll();
			}
			
			return result;
		}
	}
//	private byte[] readResult(int numBytes, Queue<Byte> buffer) {
//		int numBytesToRead = Math.min(numBytes, buffer.size());
//		
//		if (numBytesToRead == 0) {
//			return null;
//		} else {
//			byte[] result = new byte[numBytesToRead];
//			
//			for (int i = 0; i < numBytesToRead; i++) {
//				result[i] = buffer.poll();
//			}
//			
//			return result;
//		}
//	}
	
}
