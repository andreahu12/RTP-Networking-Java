
public enum ServerConnectionState {
	LISTEN,
	SYN_SENT,
	SYN_RCVD,
	ESTAB,
	CLOSE_WAIT,
	LAST_ACK,
	CLOSED
}
