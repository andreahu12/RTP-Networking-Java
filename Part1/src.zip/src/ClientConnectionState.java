
public enum ClientConnectionState {
	LISTEN,
	SYN_SENT,
	ESTAB,
	FIN_WAIT_1,
	FIN_WAIT_2,
	TIMED_WAIT,
	CLOSED
}
