
public class ftaclient {

	public static void main(String[] args) {
		// java ftaclient H:P W
			// H: IP Address OR Host Name of ftaserver
			// P: UDP Port Number of ftaserver
			// W: Receive window size at ftaclient (in bytes)
		// get F
			// download file named "get_F" from server
		// get-post F G
			// download "get_F", upload "post_G"
		// disconnect: terminate gracefully
		// TODO Auto-generated method stub

	}

}
