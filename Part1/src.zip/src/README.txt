README

Author: Andrea Hu (ahu35@gatech.edu)
Project 2 Submission