
public class ftaserver {

	public static void main(String[] args) {
		// input: $ java ftaserver P W
		// TODO Auto-generated method stub
		
	}

}
